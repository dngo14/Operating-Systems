/* Header file for example of system call library function.
   #include this file in your test program */
int dub2(int fd, int fd2);
int ngo8_mycall();
int ngo8_putval(int value);
int ngo8_getval(int value);
int mean(int value);
struct stat * ngo8_fstat(unsigned int fd, struct stat* statbuf);
