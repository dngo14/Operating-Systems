/* library source for new system calls */

#define _GNU_SOURCE
#include <unistd.h>
#include <sys/syscall.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>

extern int errno;

#define __NR_dub2		 33
#define __NR_ngo8_mycall         449
#define __NR_ngo8_putval         450
#define __NR_ngo8_getval         451
#define __NR_mean        	  452
#define __NR_ngo8_fstat	  453
/* NOTE:  for M1 ONLY, uncomment the following line */
/* #define __NR_dub2		 63 */

int dub2(int fd, int fd2) {
  return syscall(__NR_dub2, fd, fd2);
}

int ngo8_mycall() {
  return syscall(__NR_ngo8_mycall);
}

int ngo8_putval(int value) {
  return syscall(__NR_ngo8_putval, value);
}

int ngo8_getval(int value) {
  return syscall(__NR_ngo8_getval, value);
}

int mean(int value) {
  return syscall(__NR_mean, value);
}

struct stat * ngo8_fstat(unsigned int fd, struct stat* statbuf) {
	return(__NR_ngo8_fstat, fd, statbuf);
}

/* The following would appear in the caller's program...

main()
{
  dub2(1, 5);
}


*/
