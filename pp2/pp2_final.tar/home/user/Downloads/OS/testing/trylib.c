/* test program for lib.c */

#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include "lib.h"
#include <sys/time.h>
#include <sys/resource.h>
#include <sys/stat.h>
#include <ctype.h>
#include <fcntl.h>

int main()
{
  int rv;
  char *msg = "Hello, world!\n";
  printf("dub2(1,5) returns %d\n", rv = dub2(1, 5));
  
  //Test of getpid clone call (ngo8_mycall)

  printf("Test of write on fd %d:\n", rv);
  write(rv, msg, strlen(msg));
  printf("%d\n", ngo8_mycall());

  //Test of ngo8_getval and ngo8_putval
  
  int pid;
  if ((pid = getpid()) < 0) {
  	perror("getpid() error");
  	return -1;
  	}
  
  printf("pid returns %d\n", pid);
  
  int val;
  if ((val = ngo8_getval(pid)) < 0) {
  	perror("ngo8_getval() error");
  	return -1;
  	}
  printf("getval returns %d\n", val);
  
  int returnvalue;
  if ((returnvalue = ngo8_putval(2)) < 0) {
  	perror("ngo8_putval error");
  	return -1;
  	}
  	
  if ((val = ngo8_getval(pid)) < 0) {
  	perror("ngo8_getval() error");
  	return -1;
  	}
  printf("After using ngo8_putval(2), getval returns %d\n", val);
  
  //Test of mean call
  
  int priority;
  if ((priority = getpriority(PRIO_PROCESS, pid)) < 0) {
  	perror("getpriority error");
  	return -1;
  	}
 
  printf("Priority value is %d\n", priority);
  
  int val2;
  if ((val2 = mean(3)) == -1) {
  	perror("mean error");
  	return -1;
  	}
  	
  if ((priority = getpriority(PRIO_PROCESS, pid)) == -1) {
  	perror("getpriority error");
  	return -1;
  	}
  printf("New priority value is %d\n", priority);
  
  //Test of clone of fstat (ngo8_fstat)
  
  struct stat *ret;
  int fd;
  
  if ((fd = open("text.txt", O_RDONLY)) < 0) {
  	perror("open error");
  	return -1;
  	}
  
  struct stat buf;
  
  if ((ret = ngo8_fstat(fd, &buf)) < 0) {
  	perror("ngo8_fstat error");
  	return -1;
  	}
  	
  printf("The Device ID is %lu\nThe File Serial Number is %lu\nThe Mode of File is %u\n", buf.st_dev, buf.st_ino, buf.st_mode);
  
  
  
  return 0;
}
