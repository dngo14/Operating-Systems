/* Header file for example of system call library function.
   #include this file in your test program */

int dub2(int fd, int fd2);
int ngo8_mycall();
