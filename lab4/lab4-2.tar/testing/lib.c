/* library source for new system calls */

#define _GNU_SOURCE
#include <unistd.h>
#include <sys/syscall.h>
#include <stdio.h>
#include <sys/types.h>

extern int errno;

#define __NR_dub2		 33
#define __NR_ngo8_mycall         449
/* NOTE:  for M1 ONLY, uncomment the following line */
/* #define __NR_dub2		 63 */

int dub2(int fd, int fd2) {
  return syscall(__NR_dub2, fd, fd2);
}

int ngo8_mycall() {
  return syscall(__NR_ngo8_mycall);
}

/* The following would appear in the caller's program...

main()
{
  dub2(1, 5);
}


*/
