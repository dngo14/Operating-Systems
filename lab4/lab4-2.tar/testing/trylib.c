/* test program for lib.c */

#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include "lib.h"

int main()
{
  int rv;
  char *msg = "Hello, world!\n";
  printf("dub2(1,5) returns %d\n", rv = dub2(1, 5));

  printf("Test of write on fd %d:\n", rv);
  write(rv, msg, strlen(msg));
  printf("%d\n", ngo8_mycall());
  printf("%d\n", getpid());
  return 0;
}
